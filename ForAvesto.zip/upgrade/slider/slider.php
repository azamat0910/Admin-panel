<?php
$user = "root";
$host = "localhost";
$password = "root";
$db = "upgrade";
$dbh = "mysql:host=".$host.";dbname=".$db. ";charset=utf8"; 
$pdo = new PDO ($dbh, $user, $password);

?>


<?php

if(isset($_POST["save"])){
    $list = ['.php','.zip', '.js', '.html'];
        foreach($list as $item){
            if(preg_match("/$item$/", $_FILES['im']['name']))exit("Расширение файла не подходит");
        }
    $type = getimagesize($_FILES['im']['tmp_name']);
    if($type && ($type['mime'] != ' image/png' || $type['mime'] != 'image/jpg' || $type['mime'] != 'image/jpeg')){
        if($_FILES['im']['name']<1024*1000){
            $upload = 'img/'.$_FILES['im']['name'];
            if(move_uploaded_file($_FILES['im']['tmp_name'], $upload))echo 'Файл загружен';
            else echo 'Ошибка при загрузке файла';
        }
        else exit('Размер файла превышен');
    }
    else exit('Тип файла не подходит');
}
?>
<?php

if(isset($_POST["save2"])){
    $list = ['.php','.zip', '.js', '.html'];
        foreach($list as $item){
            if(preg_match("/$item$/", $_FILES['im2']['name']))exit("Расширение файла не подходит");
        }
    $type = getimagesize($_FILES['im2']['tmp_name']);
    if($type && ($type['mime'] != ' image/png' || $type['mime'] != 'image/jpg' || $type['mime'] != 'image/jpeg')){
        if($_FILES['im2']['name']<1024*1000){
            $upload = 'img/'.$_FILES['im2']['name'];
            if(move_uploaded_file($_FILES['im2']['tmp_name'], $upload))echo 'Файл загружен';
            else echo 'Ошибка при загрузке файла';
        }
        else exit('Размер файла превышен');
    }
    else exit('Тип файла не подходит');
}       
?>
<?php

if(isset($_POST["save3"])){
    $list = ['.php','.zip', '.js', '.html'];
        foreach($list as $item){
            if(preg_match("/$item$/", $_FILES['im3']['name']))exit("Расширение файла не подходит");
        }
    $type = getimagesize($_FILES['im3']['tmp_name']);
    if($type && ($type['mime'] != ' image/png' || $type['mime'] != 'image/jpg' || $type['mime'] != 'image/jpeg')){
        if($_FILES['im3']['name']<1024*1000){
            $upload = 'img/'.$_FILES['im3']['name'];
            if(move_uploaded_file($_FILES['im3']['tmp_name'], $upload))echo 'Файл загружен';
            else echo 'Ошибка при загрузке файла';
        }
        else exit('Размер файла превышен');
    }
    else exit('Тип файла не подходит');
}       
?>
<?php

if(isset($_POST["save4"])){
    $list = ['.php','.zip', '.js', '.html'];
        foreach($list as $item){
            if(preg_match("/$item$/", $_FILES['im4']['name']))exit("Расширение файла не подходит");
        }
    $type = getimagesize($_FILES['im4']['tmp_name']);
    if($type && ($type['mime'] != ' image/png' || $type['mime'] != 'image/jpg' || $type['mime'] != 'image/jpeg')){
        if($_FILES['im4']['name']<1024*1000){
            $upload = 'img/'.$_FILES['im4']['name'];
            if(move_uploaded_file($_FILES['im4']['tmp_name'], $upload))echo 'Файл загружен';
            else echo 'Ошибка при загрузке файла';
        }
        else exit('Размер файла превышен');
    }
    else exit('Тип файла не подходит');
}       
?>
<?php

if(isset($_POST["save5"])){
    $list = ['.php','.zip', '.js', '.html'];
        foreach($list as $item){
            if(preg_match("/$item$/", $_FILES['im5']['name']))exit("Расширение файла не подходит");
        }
    $type = getimagesize($_FILES['im5']['tmp_name']);
    if($type && ($type['mime'] != ' image/png' || $type['mime'] != 'image/jpg' || $type['mime'] != 'image/jpeg')){
        if($_FILES['im5']['name']<1024*1000){
            $upload = 'img/'.$_FILES['im5']['name'];
            if(move_uploaded_file($_FILES['im5']['tmp_name'], $upload))echo 'Файл загружен';
            else echo 'Ошибка при загрузке файла';
        }
        else exit('Размер файла превышен');
    }
    else exit('Тип файла не подходит');
}       
?>
<?php

if(isset($_POST["save6"])){
    $list = ['.php','.zip', '.js', '.html'];
        foreach($list as $item){
            if(preg_match("/$item$/", $_FILES['im6']['name']))exit("Расширение файла не подходит");
        }
    $type = getimagesize($_FILES['im6']['tmp_name']);
    if($type && ($type['mime'] != ' image/png' || $type['mime'] != 'image/jpg' || $type['mime'] != 'image/jpeg')){
        if($_FILES['im6']['name']<1024*1000){
            $upload = 'img/'.$_FILES['im6']['name'];
            if(move_uploaded_file($_FILES['im6']['tmp_name'], $upload))echo 'Файл загружен';
            else echo 'Ошибка при загрузке файла';
        }
        else exit('Размер файла превышен');
    }
    else exit('Тип файла не подходит');
}       
?>

<?php
    $prof = $_POST["prof"];
    $company = $_POST["company"];
    $info = $_POST["info"];
    $filename = $_POST["im"];

    $sql = "UPDATE jobs SET profession=:profession,company=:company,info=:info,filename=:filename WHERE id=1" ;
    $query=$pdo->prepare($sql);
    $query->execute(["profession"=>$prof, "company"=>$company, "info"=>$info, "filename"=>$_FILES['im']['name']]);

?>
<?php
    $prof = $_POST["prof2"];
    $company = $_POST["company2"];
    $info = $_POST["info2"];
    $filename = $_POST["im2"];

    $sql = "UPDATE jobs SET profession=:profession,company=:company,info=:info,filename=:filename WHERE id=2" ;
    $query=$pdo->prepare($sql);
    $query->execute(["profession"=>$prof, "company"=>$company, "info"=>$info, "filename"=>$_FILES['im2']['name']]);

?>
<?php
    $prof = $_POST["prof3"];
    $company = $_POST["company3"];
    $info = $_POST["info3"];
    $filename = $_POST["im3"];

    $sql = "UPDATE jobs SET profession=:profession,company=:company,info=:info,filename=:filename WHERE id=3" ;
    $query=$pdo->prepare($sql);
    $query->execute(["profession"=>$prof, "company"=>$company, "info"=>$info, "filename"=>$_FILES['im3']['name']]);

?>
<?php
    $prof = $_POST["prof4"];
    $company = $_POST["company4"];
    $info = $_POST["info4"];
    $filename = $_POST["im4"];

    $sql = "UPDATE jobs SET profession=:profession,company=:company,info=:info,filename=:filename WHERE id=4" ;
    $query=$pdo->prepare($sql);
    $query->execute(["profession"=>$prof, "company"=>$company, "info"=>$info, "filename"=>$_FILES['im4']['name']]);

?>
<?php
    $prof = $_POST["prof5"];
    $company = $_POST["company5"];
    $info = $_POST["info5"];
    $filename = $_POST["im5"];

    $sql = "UPDATE jobs SET profession=:profession,company=:company,info=:info,filename=:filename WHERE id=5" ;
    $query=$pdo->prepare($sql);
    $query->execute(["profession"=>$prof, "company"=>$company, "info"=>$info, "filename"=>$_FILES['im5']['name']]);

?>
<?php
    $prof = $_POST["prof6"];
    $company = $_POST["company6"];
    $info = $_POST["info6"];
    $filename = $_POST["im6"];

    $sql = "UPDATE jobs SET profession=:profession,company=:company,info=:info,filename=:filename WHERE id=6" ;
    $query=$pdo->prepare($sql);
    $query->execute(["profession"=>$prof, "company"=>$company, "info"=>$info, "filename"=>$_FILES['im6']['name']]);

?>


