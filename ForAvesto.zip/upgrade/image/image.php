<?php
$user = "root";
$host = "localhost";
$password = "root";
$db = "upgrade";
$dbh = "mysql:host=".$host.";dbname=".$db. ";charset=utf8"; 
$pdo = new PDO ($dbh, $user, $password);

?>

<?php

if(isset($_POST["save9"])){
    $list = ['.php','.zip', '.js', '.html'];
        foreach($list as $item){
            if(preg_match("/$item$/", $_FILES['image']['name']))exit("Расширение файла не подходит");
        }
    $type = getimagesize($_FILES['image']['tmp_name']);
    if($type && ($type['mime'] != ' image/png' || $type['mime'] != 'image/jpg' || $type['mime'] != 'image/jpeg')){
        if($_FILES['image']['name']<8024*1000){
            $upload = 'img/'.$_FILES['image']['name'];
            if(move_uploaded_file($_FILES['image']['tmp_name'], $upload))echo 'Файл загружен';
            else echo 'Ошибка при загрузке файла';
        }
        else exit('Размер файла превышен');
    }
    else exit('Тип файла не подходит');
}
?>
<?php
    $filename = $_POST["image"];

    $sql = "UPDATE image SET filename=:filename WHERE id=1" ;
    $query=$pdo->prepare($sql);
    $query->execute(["filename"=>$_FILES['image']['name']]);

?>