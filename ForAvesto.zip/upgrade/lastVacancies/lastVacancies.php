<?php
$user = "root";
$host = "localhost";
$password = "root";
$db = "upgrade";
$dbh = "mysql:host=".$host.";dbname=".$db. ";charset=utf8"; 
$pdo = new PDO ($dbh, $user, $password);

?>
<?php

if(isset($_POST["save4"])){
    $list = ['.php','.zip', '.js', '.html'];
        foreach($list as $item){
            if(preg_match("/$item$/", $_FILES['im4']['name']))exit("Расширение файла не подходит");
        }
    $type = getimagesize($_FILES['im4']['tmp_name']);
    if($type && ($type['mime'] != ' image/png' || $type['mime'] != 'image/jpg' || $type['mime'] != 'image/jpeg')){
        if($_FILES['im4']['name']<1024*1000){
            $upload = 'img/'.$_FILES['im4']['name'];
            if(move_uploaded_file($_FILES['im4']['tmp_name'], $upload))echo 'Файл загружен';
            else echo 'Ошибка при загрузке файла';
        }
        else exit('Размер файла превышен');
    }
    else exit('Тип файла не подходит');
}
?>
<?php

if(isset($_POST["save5"])){
    $list = ['.php','.zip', '.js', '.html'];
        foreach($list as $item){
            if(preg_match("/$item$/", $_FILES['im5']['name']))exit("Расширение файла не подходит");
        }
    $type = getimagesize($_FILES['im5']['tmp_name']);
    if($type && ($type['mime'] != ' image/png' || $type['mime'] != 'image/jpg' || $type['mime'] != 'image/jpeg')){
        if($_FILES['im5']['name']<1024*1000){
            $upload = 'img/'.$_FILES['im5']['name'];
            if(move_uploaded_file($_FILES['im5']['tmp_name'], $upload))echo 'Файл загружен';
            else echo 'Ошибка при загрузке файла';
        }
        else exit('Размер файла превышен');
    }
    else exit('Тип файла не подходит');
}
?>
<?php

if(isset($_POST["save6"])){
    $list = ['.php','.zip', '.js', '.html'];
        foreach($list as $item){
            if(preg_match("/$item$/", $_FILES['im6']['name']))exit("Расширение файла не подходит");
        }
    $type = getimagesize($_FILES['im6']['tmp_name']);
    if($type && ($type['mime'] != ' image/png' || $type['mime'] != 'image/jpg' || $type['mime'] != 'image/jpeg')){
        if($_FILES['im6']['name']<1024*1000){
            $upload = 'img/'.$_FILES['im6']['name'];
            if(move_uploaded_file($_FILES['im6']['tmp_name'], $upload))echo 'Файл загружен';
            else echo 'Ошибка при загрузке файла';
        }
        else exit('Размер файла превышен');
    }
    else exit('Тип файла не подходит');
}
?>
<?php

if(isset($_POST["save7"])){
    $list = ['.php','.zip', '.js', '.html'];
        foreach($list as $item){
            if(preg_match("/$item$/", $_FILES['im7']['name']))exit("Расширение файла не подходит");
        }
    $type = getimagesize($_FILES['im7']['tmp_name']);
    if($type && ($type['mime'] != ' image/png' || $type['mime'] != 'image/jpg' || $type['mime'] != 'image/jpeg')){
        if($_FILES['im7']['name']<1024*1000){
            $upload = 'img/'.$_FILES['im7']['name'];
            if(move_uploaded_file($_FILES['im7']['tmp_name'], $upload))echo 'Файл загружен';
            else echo 'Ошибка при загрузке файла';
        }
        else exit('Размер файла превышен');
    }
    else exit('Тип файла не подходит');
}
?>
<?php

if(isset($_POST["save8"])){
    $list = ['.php','.zip', '.js', '.html'];
        foreach($list as $item){
            if(preg_match("/$item$/", $_FILES['im8']['name']))exit("Расширение файла не подходит");
        }
    $type = getimagesize($_FILES['im8']['tmp_name']);
    if($type && ($type['mime'] != ' image/png' || $type['mime'] != 'image/jpg' || $type['mime'] != 'image/jpeg')){
        if($_FILES['im8']['name']<1024*1000){
            $upload = 'img/'.$_FILES['im8']['name'];
            if(move_uploaded_file($_FILES['im8']['tmp_name'], $upload))echo 'Файл загружен';
            else echo 'Ошибка при загрузке файла';
        }
        else exit('Размер файла превышен');
    }
    else exit('Тип файла не подходит');
}
?>
<?php
    $title = $_POST["title"];
    $info = $_POST["info"];
    $filename = $_POST["im4"];
    $row = "UPDATE lastvacancies SET title=:title,info=:info,filename=:filename WHERE id=1" ;
    $query=$pdo->prepare($row);
    $query->execute(["title"=>$title,"info"=>$info,"filename"=>$_FILES['im4']['name']]);

?>
<?php
    $title = $_POST["title2"];
    $info = $_POST["info2"];
    $filename = $_POST["im5"];

    $sql = "UPDATE lastvacancies SET info=:info,title=:title, filename=:filename WHERE id=2" ;
    $query=$pdo->prepare($sql);
    $query->execute(["info"=>$info,"title"=>$title, "filename"=>$_FILES['im5']['name']]);

?>
<?php
    $title = $_POST["title3"];
    $info = $_POST["info3"];
    $filename = $_POST["im6"];

    $sql = "UPDATE lastvacancies SET info=:info,title=:title, filename=:filename WHERE id=3" ;
    $query=$pdo->prepare($sql);
    $query->execute(["info"=>$info,"title"=>$title, "filename"=>$_FILES['im6']['name']]);

?>
<?php
    $title = $_POST["title4"];
    $info = $_POST["info4"];
    $filename = $_POST["im7"];

    $sql = "UPDATE lastvacancies SET info=:info,title=:title, filename=:filename WHERE id=4" ;
    $query=$pdo->prepare($sql);
    $query->execute(["info"=>$info,"title"=>$title, "filename"=>$_FILES['im7']['name']]);

?>
<?php
    $title = $_POST["title5"];
    $info = $_POST["info5"];
    $filename = $_POST["im8"];

    $sql = "UPDATE lastvacancies SET info=:info,title=:title, filename=:filename WHERE id=5" ;
    $query=$pdo->prepare($sql);
    $query->execute(["info"=>$info,"title"=>$title, "filename"=>$_FILES['im8']['name']]);

?>