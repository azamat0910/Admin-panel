<?php
$user = "root";
$host = "localhost";
$password = "root";
$db = "upgrade";
$dbh = "mysql:host=".$host.";dbname=".$db. ";charset=utf8"; 
$pdo = new PDO ($dbh, $user, $password);

?>

<?php 
    $first = $_POST["first"];
    $second = $_POST["second"];
    $third = $_POST["third"];
    $fourth = $_POST["fourth"];
    $row = "UPDATE header SET first=:first,second=:second,third=:third,fourth=:fourth" ;
    $query=$pdo->prepare($row);
    $query->execute(["first"=>$first, "second"=>$second, "third"=>$third, "fourth"=>$fourth]);
    echo '<meta HTTP-EQUIV="Refresh" Content="0; URL=../header.php">';
?>
