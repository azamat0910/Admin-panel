<?php
$user = "root";
$host = "localhost";
$password = "root";
$db = "upgrade";
$dbh = "mysql:host=".$host.";dbname=".$db. ";charset=utf8"; 
$pdo = new PDO ($dbh, $user, $password);

?>